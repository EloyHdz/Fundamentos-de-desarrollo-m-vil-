import 'dart:math';
import 'package:flutter/material.dart';

class ParticulasFondo extends StatefulWidget {
  final Widget child;

  const ParticulasFondo({
    super.key,
    required this.child,
  });

  @override
  State<ParticulasFondo> createState() => _ParticulasFondoState();
}

class _ParticulasFondoState extends State<ParticulasFondo>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        return CustomPaint(
          painter: ParticulasPainter(controller.value),
          child: widget.child,
        );
      },
    );
  }
}

class ParticulasPainter extends CustomPainter {
  final double progress;

  ParticulasPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final random = Random(42);

    for (int i = 0; i < 80; i++) {
      final paint = Paint()
        ..color = const Color(0xFF00E5FF).withOpacity(0.15);

      double x =
          (random.nextDouble() * size.width + progress * 50 * i) %
              size.width;

      double y =
          (random.nextDouble() * size.height + progress * 20 * i) %
              size.height;

      canvas.drawCircle(
        Offset(x, y),
        random.nextDouble() * 2 + 1,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}