import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/partido.dart';

class FichaPartido extends StatefulWidget {
  final Partido partido;

  const FichaPartido({
    super.key,
    required this.partido,
  });

  @override
  State<FichaPartido> createState() => _FichaPartidoState();
}

class _FichaPartidoState extends State<FichaPartido>
    with TickerProviderStateMixin {
  late AnimationController glowController;
  late AnimationController blinkController;

  late Animation<double> glowAnimation;
  late Animation<double> blinkAnimation;

  @override
  void initState() {
    super.initState();

    glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    blinkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    glowAnimation = Tween<double>(
      begin: 8,
      end: 30,
    ).animate(glowController);

    blinkAnimation = Tween<double>(
      begin: 0.55,
      end: 1.0,
    ).animate(blinkController);
  }

  @override
  void dispose() {
    glowController.dispose();
    blinkController.dispose();
    super.dispose();
  }

  Widget logoGlitch(String logo, bool izquierda) {
    return AnimatedBuilder(
      animation: blinkController,
      builder: (context, child) {
        final desplazamiento =
            sin(blinkController.value * 2 * pi) * 10;

        return Transform.translate(
          offset: Offset(
            izquierda ? desplazamiento : -desplazamiento,
            0,
          ),
          child: Opacity(
            opacity: blinkAnimation.value,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Transform.translate(
                  offset: const Offset(-3, 0),
                  child: ColorFiltered(
                    colorFilter: const ColorFilter.mode(
                      Colors.cyan,
                      BlendMode.modulate,
                    ),
                    child: Image.network(
                      logo,
                      height: 80,
                    ),
                  ),
                ),

                Transform.translate(
                  offset: const Offset(3, 0),
                  child: ColorFiltered(
                    colorFilter: const ColorFilter.mode(
                      Colors.pink,
                      BlendMode.modulate,
                    ),
                    child: Image.network(
                      logo,
                      height: 80,
                    ),
                  ),
                ),

                Image.network(
                  logo,
                  height: 80,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final partido = widget.partido;

    final fecha = DateFormat(
      'dd/MM/yyyy',
    ).format(DateTime.parse(partido.fecha));

    return AnimatedBuilder(
      animation: glowAnimation,
      builder: (context, child) {
        return Container(
          margin: const EdgeInsets.symmetric(
            horizontal: 15,
            vertical: 10,
          ),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF111827),
            borderRadius: BorderRadius.circular(25),
            border: Border.all(
              color: const Color(0xFF00E5FF),
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color:
                    const Color(0xFF00E5FF).withOpacity(.8),
                blurRadius: glowAnimation.value,
                spreadRadius: 3,
              ),
            ],
          ),
          child: Column(
            children: [
              Text(
                partido.visitante.toUpperCase(),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF00E5FF),
                  fontSize: 22,
                  letterSpacing: 2,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 25),

              Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceEvenly,
                children: [
                  logoGlitch(
                    partido.logoVisitante,
                    true,
                  ),

                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0x22FF00E5),
                      border: Border.all(
                        color: const Color(0xFFFF00E5),
                        width: 2,
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xFFFF00E5),
                          blurRadius: 30,
                          spreadRadius: 3,
                        )
                      ],
                    ),
                    child: const Text(
                      "VS",
                      style: TextStyle(
                        color: Color(0xFFFF00E5),
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),

                  logoGlitch(
                    partido.logoLocal,
                    false,
                  ),
                ],
              ),

              const SizedBox(height: 25),

              Text(
                partido.local.toUpperCase(),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 20),

              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  borderRadius:
                      BorderRadius.circular(30),
                  color: const Color(0xFF7B2FFF),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xFF7B2FFF),
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: Text(
                  fecha,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}