class Partido {
  final String local;
  final String visitante;
  final String fecha;
  final String logoLocal;
  final String logoVisitante;

  const Partido({
    required this.local,
    required this.visitante,
    required this.fecha,
    required this.logoLocal,
    required this.logoVisitante,
  });

  factory Partido.fromJson(Map<String, dynamic> json) {
    final competition = json['competitions'][0];

    final home = competition['competitors']
        .firstWhere((equipo) => equipo['homeAway'] == 'home');

    final away = competition['competitors']
        .firstWhere((equipo) => equipo['homeAway'] == 'away');

    return Partido(
      local: home['team']['displayName'],
      visitante: away['team']['displayName'],
      fecha: json['date'],
      logoLocal: home['team']['logo'],
      logoVisitante: away['team']['logo'],
    );
  }
}