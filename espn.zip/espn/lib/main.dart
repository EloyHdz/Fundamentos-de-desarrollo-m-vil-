import 'package:flutter/material.dart';
import 'screens/nfl_screen.dart';

void main() {
  runApp(const MiApp());
}

class MiApp extends StatelessWidget {
  const MiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NFL',
      theme: ThemeData.dark(),
      home: const NflScreen(),
    );
  }
}