import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/partido.dart';

Future<List<Partido>> obtenerPartidos() async {
  final respuesta = await http.get(
    Uri.parse(
      'https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard',
    ),
  );

  if (respuesta.statusCode != 200) {
    throw Exception('Error al consultar ESPN');
  }

  final datos = jsonDecode(respuesta.body);

  return (datos['events'] as List)
      .map((evento) => Partido.fromJson(evento))
      .toList();
}