import 'package:flutter/material.dart';

import '../models/partido.dart';
import '../services/servicios_espn.dart';
import '../widgets/ficha_partido.dart';

import '../widgets/particulas_fondo.dart';

class NflScreen extends StatefulWidget {
  const NflScreen({super.key});

  @override
  State<NflScreen> createState() => _NflScreenState();
}

class _NflScreenState extends State<NflScreen> {
  List<Partido> partidos = [];

  bool cargando = true;

  String? error;

  @override
  void initState() {
    super.initState();
    cargarPartidos();
  }

  Future<void> cargarPartidos() async {
    try {
      final datos = await obtenerPartidos();

      setState(() {
        partidos = datos;
        cargando = false;
      });
    } catch (e) {
      setState(() {
        error = "No se pudo conectar con ESPN";
        cargando = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E21),

      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          "NFL",
          style: TextStyle(
            color: Color(0xFF00E5FF),
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
          ),
        ),
      ),

      body: ParticulasFondo(
  child: cargando
      ? const Center(
          child: CircularProgressIndicator(
            color: Color(0xFF00E5FF),
          ),
        )
      : error != null
          ? Center(
              child: Text(
                error!,
                style: const TextStyle(
                  color: Colors.white,
                ),
              ),
            )
          : ListView(
              children: [
                const SizedBox(height: 30),

                const Icon(
                  Icons.sports_football,
                  size: 90,
                  color: Color(0xFF00E5FF),
                ),

                const SizedBox(height: 10),

                const Center(
                  child: Text(
                    "NFL CYBER GRID",
                    style: TextStyle(
                      color: Color(0xFF00E5FF),
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 4,
                    ),
                  ),
                ),

                const SizedBox(height: 30),

                ...partidos.map(
                  (e) => FichaPartido(partido: e),
                ),
              ],
            ),
        ),
    );
  }
}